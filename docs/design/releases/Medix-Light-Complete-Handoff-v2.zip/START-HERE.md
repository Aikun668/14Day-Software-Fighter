# Medix Light 完整交接包 v2

从[总HANDOFF](docs/design/medix-light/handoff-final-v2/HANDOFF.md)开始。

本版补齐07患者报告独立图、独立规格与独立验收。用户已明确通过最终07图并要求归档。

[07批准图](docs/design/medix-light/handoff-07-v1/references/07-patient-report.png) · [07独立规格](docs/design/medix-light/handoff-07-v1/07-PATIENT-REPORT.md) · [总终验报告](docs/design/medix-light/handoff-final-v2/REVIEW.md)

旧v1文件与review目录留作历史；当前总入口为v2，07构图以独立补充包为准。代码实际运行仍待实施验收。13/14留存参考状态未改变。

解压后在本目录执行：

```powershell
python docs/design/medix-light/handoff-final-v2/verify.py --portable
```

portable仅略过可能被解压工具丢失的只读属性，仍检查哈希、链接、15张图清单及07数据核算。包内没有应用源代码，不加--check-source。
