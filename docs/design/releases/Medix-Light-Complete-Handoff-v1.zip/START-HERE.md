# Medix Light 完整设计交接包 v1

从 [总HANDOFF](docs/design/medix-light/handoff-final-v1/HANDOFF.md) 开始。

00–15规格与指定图片、冲突裁决、实施任务和验收表都在包内。review目录保留历史来源，不是当前实施基准。

本包是设计规格，未声称代码已实现。13/14为留存参考图，审批状态在清单如实记录。

解压到任意目录后，在该目录运行：

```powershell
python docs/design/medix-light/handoff-final-v1/verify.py --portable
```

此命令检查文件哈希、链接、图源和冻结清单；portable只略过可能被解压工具丢失的只读属性。不要加--check-source：包内不包含应用源代码。
